package childs.book;
import childs.person.Mangaka;
import publisher.Publisher;

public class Comic extends Book{
    // attributes
    private boolean volumeSeries;

    // constructor
    public Comic(){
        super();
    }

}


