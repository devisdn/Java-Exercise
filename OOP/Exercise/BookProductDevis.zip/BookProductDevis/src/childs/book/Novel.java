package childs.book;

public class Novel extends Book{
    // attributes
    private String genre;

    public Novel(){
        super();
    }
}
