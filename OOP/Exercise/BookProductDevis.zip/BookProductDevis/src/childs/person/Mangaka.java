package childs.person;

public class Mangaka {
    // attributes
    private String rating;
    
}
