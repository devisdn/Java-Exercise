package publisher;

public class Publisher {
    // attributes
    private String name, country;
    private double productionCost;
    
    // constructor
    public Publisher() { }

    public Publisher(String name, String country, double productionCost){
        this.name = name;
        this.country = country;
        this.productionCost = productionCost;
    }

    // getter
    public String getName(){
        return name;
    }

    public String getCountry(){
        return country;
    }

    public double getProductioncost(){
        return productionCost;
    }

    // setter
    public void setName(String name){
        this.name = name;
    }

    public void setCountry(String country){
        this.country = country;
    }

    public void setProductionCost(double productionCost){
        this.productionCost = productionCost;
    }
    
}
